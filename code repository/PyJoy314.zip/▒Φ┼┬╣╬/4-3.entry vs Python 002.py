M = int(input())

if M % 400 == 0 :
    print("leap year")
elif M % 4 == 0 and M % 100 == 0 :
    print("leap year")
else :
    print("common year")
