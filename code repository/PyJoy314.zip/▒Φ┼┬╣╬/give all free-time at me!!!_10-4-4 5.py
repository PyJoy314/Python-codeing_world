n, o = input().split()
o = int(o)
s, a = input().split()
a = int(a)
age = o - a
print(f"{n}'s age - {s}'s age = {age}")
