name = input().strip()
age = int(input())
print(f"{name} is {age} years old.")
