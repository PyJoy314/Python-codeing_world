while True:
    N = int(input())
    if N == 0:
        break
    print("N =", N)
