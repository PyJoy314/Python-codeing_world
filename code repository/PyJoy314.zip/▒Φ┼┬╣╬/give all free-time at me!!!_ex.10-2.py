M = input().strip()

print(f"{M}'s score 'perfect'")
