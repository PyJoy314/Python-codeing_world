import tkinter as tk
from tkinter import messagebox
import random

# 난이도 설정
difficulty_levels = {
    "easy": 50,
    "normal": 100,
    "hard": 200
}

# 전역 변수 초기화
answer = None
attempts_left = 10
max_number = 100

# 난이도 선택 후 게임 시작
def start_game():
    global answer, attempts_left, max_number

    level = difficulty_var.get()
    max_number = difficulty_levels[level]
    answer = random.randint(1, max_number)
    attempts_left = 10

    guess_entry.config(state="normal")
    guess_button.config(state="normal")
    info_label.config(text=f"1부터 {max_number} 사이의 숫자를 맞춰보세요! (기회: {attempts_left}번)")
    result_label.config(text="")
    guess_entry.delete(0, tk.END)

# 숫자 입력 후 확인
def check_guess():
    global answer, attempts_left

    guess = guess_entry.get()

    if not guess.isdigit():
        result_label.config(text="숫자만 입력해주세요.")
        return

    guess = int(guess)
    attempts_left -= 1

    if guess < answer:
        result_label.config(text=f"너무 작아요! 남은 기회: {attempts_left}번")
    elif guess > answer:
        result_label.config(text=f"너무 커요! 남은 기회: {attempts_left}번")
    else:
        result_label.config(text=f"정답입니다! 축하합니다!")
        end_game(win=True)
        return

    if attempts_left == 0:
        result_label.config(text=f"게임 오버! 정답은 {answer}였습니다.")
        end_game(win=False)

# 게임 종료 후 입력 제한
def end_game(win):
    guess_entry.config(state="disabled")
    guess_button.config(state="disabled")
    if win:
        messagebox.showinfo("축하합니다!", "정답을 맞췄어요!")
    else:
        messagebox.showinfo("아쉽네요", f"정답은 {answer}였습니다.")

# ---------------- GUI 구성 ----------------

root = tk.Tk()
root.title("숫자 맞추기 게임")
root.geometry("400x300")
root.resizable(False, False)

# 난이도 선택
difficulty_var = tk.StringVar(value="normal")
tk.Label(root, text="난이도 선택", font=("Arial", 12, "bold")).pack(pady=5)

difficulty_frame = tk.Frame(root)
difficulty_frame.pack()

for level in difficulty_levels:
    tk.Radiobutton(
        difficulty_frame,
        text=level.capitalize(),
        variable=difficulty_var,
        value=level
    ).pack(side="left", padx=10)

# 시작 버튼
tk.Button(root, text="게임 시작", command=start_game).pack(pady=10)

# 안내 텍스트
info_label = tk.Label(root, text="난이도를 선택하고 게임을 시작하세요.", font=("Arial", 11))
info_label.pack()

# 숫자 입력창
guess_entry = tk.Entry(root, font=("Arial", 14), justify="center", state="disabled")
guess_entry.pack(pady=5)

# 확인 버튼
guess_button = tk.Button(root, text="입력", font=("Arial", 12), command=check_guess, state="disabled")
guess_button.pack()

# 결과 표시
result_label = tk.Label(root, text="", font=("Arial", 12))
result_label.pack(pady=10)

# 실행
root.mainloop()

