h, m = input().split()
h = int(h)
m = int(m)

if h >= 12:
    P = "PM"
    if h >= 13:
        h -= 12
else:
    P = "AM"

print(f"{h:02d} : {m:02d} {P}")
