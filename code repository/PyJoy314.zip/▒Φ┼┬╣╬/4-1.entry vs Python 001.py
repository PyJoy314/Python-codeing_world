M, e = input().split()
M = int(M)
e = int(e)

if M > e :
    print(M - e)
else :
    print(e - M)
