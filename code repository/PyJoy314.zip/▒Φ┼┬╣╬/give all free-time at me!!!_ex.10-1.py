M = input().strip()
M = list(M)
print('-'.join(M))
