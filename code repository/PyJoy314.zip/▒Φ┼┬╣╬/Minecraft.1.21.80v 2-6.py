M = float(input())

print(M, "yard =", M * 91.44, "cm")
