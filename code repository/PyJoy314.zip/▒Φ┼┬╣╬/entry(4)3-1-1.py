M, e = input().split()
M = int(M)
e = int(e)

print(M, "/", e, "=", M // e, "...", M % e)
