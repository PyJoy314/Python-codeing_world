M = "name          subject"
print(M)
M = "minsoo          math"
print(M)
M = "chulsoo          science"
print(M)
