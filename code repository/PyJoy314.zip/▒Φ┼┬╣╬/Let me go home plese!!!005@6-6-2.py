while True:
    K = float(input())
    if K == 0:
        break
    if K > 0:
        print("positive")
    if K < 0:
        print("negative")
    
