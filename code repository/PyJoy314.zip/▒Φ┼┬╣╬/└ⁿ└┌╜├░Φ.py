#h = int(input())
#m = int(input())
#while True:
 #   m += 1//10
  #  if m // 60:
   #     h += 1
    #    print(f"{h:02d}:{m:02d}")

import tkinter as tk
from time import strftime

# Tkinter 윈도우 생성
root = tk.Tk()
root.title("디지털 시계")

# 시계 스타일 설정
label = tk.Label(root, font=("Helvetica", 48), background="light green", foreground="cyan")
label.pack(anchor="center")

# 시간 업데이트 함수
def update_time():
    current_time = strftime("%H:%M:%S")  # 현재 시간 가져오기
    label.config(text=current_time)     # 라벨에 시간 표시
    label.after(1000, update_time)      # 1초마다 업데이트

update_time()  # 함수 호출
root.mainloop()  # Tkinter 실행
