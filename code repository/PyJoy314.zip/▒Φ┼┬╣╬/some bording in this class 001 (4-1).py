M = int(input())

if M == 1:
    print("KOREA")
elif M == 2:
    print("USA")
elif M == 3:
    print("CHINA")
else :
    print("NO")
