name, height, weight = input().split()
height = int(height)
weight =float(weight)

print("name:", name)
print("height:", height)
print("weight:", weight)
