N = int(input())
Minecraft = 0
i = 1
while i <= N:
    Minecraft += i
    i += 1
print(Minecraft)
