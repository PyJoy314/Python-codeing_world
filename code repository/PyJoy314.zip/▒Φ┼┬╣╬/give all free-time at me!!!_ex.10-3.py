M = float(input())
Py = float(input())

R = M * Py / 2
print(f"{R :.1f}")
