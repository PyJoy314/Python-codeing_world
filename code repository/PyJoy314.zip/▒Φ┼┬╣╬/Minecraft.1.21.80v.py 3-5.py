M = True
e = False
Py = True

Minecraft1 = (M and e)
Minecraft2 = (e or Py)
Minecraft3 = (not e)

print(Minecraft1, Minecraft2, Minecraft3)
