B = list(map(int, input().split()))
print(B)
for i in B:
    print(i, end=" ")
print()
hap = sum(B)
print("hap = ", hap)
