M, e, Py = input().split()
M = int(M)
e = int(e)
Py = int(Py)

Minecraft1 = (M > e)
Minecraft2 = (e >= Py)
Minecraft3 = (M <= e)
Minecraft4 = (e < Py)

print(Minecraft1, Minecraft2, Minecraft3, Minecraft4)

