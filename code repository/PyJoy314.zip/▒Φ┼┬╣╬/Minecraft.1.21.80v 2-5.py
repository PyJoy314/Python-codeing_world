M, e = input().split()
M = int(M)
e = float(e)

print(M,"+", e, "=", M + e)
