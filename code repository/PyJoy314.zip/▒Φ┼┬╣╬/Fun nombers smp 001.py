N = int(input())

if N == 0 :
    print("ZERO")
elif N > 0:
    print("PLUS")
elif N < 0:
    print("MINUS")
    
    
    
