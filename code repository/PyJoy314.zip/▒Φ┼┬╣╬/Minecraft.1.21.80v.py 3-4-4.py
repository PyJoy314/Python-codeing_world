M, e = input().split()
M = int(M)
e = int(e)

Minecraft1 = (M > e)
Minecraft2 = (M >= e)
Minecraft3 = (M < e)
Minecraft4 = (M <= e)

print(M, ">", e, "==", Minecraft1)
print(M, ">=", e, "==", Minecraft2)
print(M, "<", e, "==", Minecraft3)
print(M, "<=", e, "==", Minecraft4)
