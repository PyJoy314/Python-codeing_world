A = input().strip()
B = input().strip()

if A == "efabcdefa" and B == "cdefab":
    print("YES")
else :
    print("NO")
