while True:
    N = int(input())
    if (N < 0) or (N > 100):
        break
    print("Score: ", N)
