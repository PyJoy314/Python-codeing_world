minecraft, entry, mblock, py = input().split()
minecraft = int(minecraft)
entry = int(entry)
mblock = int(mblock)
py = int(py)

print("total sum =", minecraft + entry + mblock + py)
