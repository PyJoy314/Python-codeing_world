X = int(input())
Y = int(input())
O = input().strip()

if O == "+" :
    print("ans =", X + Y)
elif O == "-" :
    print("ans =", X - Y)
elif O == "*" :
    print("ans =", X * Y)
else :
    print("ans =", X % Y)


