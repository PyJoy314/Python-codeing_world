M, e, Py = input().split()
M = int(M)
e = int(e)
Py = int(Py)

print("sum =", M + e + Py)
print("avg =", (M + e + Py)//3)
