minecraft, entry = input().split()
minecraft = int(minecraft)
entry = int(entry)

print(minecraft, "**", entry, "=", minecraft ** entry) 
