M = int(input())
e = int(input())
Py = int(input())
d = int(input())
i = int(input())
y = int(input())
k = int(input())

M = M + 2
e = e - 2
Py = Py * 2
d = d / 2
i = i // 2
y = y % 2
k = k ** 2

print(M, e, Py, d, i, y, k)
