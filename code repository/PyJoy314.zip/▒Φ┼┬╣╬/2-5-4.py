minecraft, entry = input().split()
minecraft = int(minecraft)
entry = int(entry)

mblock, py = input().split()
mblock = int(mblock)
py = int(py)

print(minecraft * mblock + entry * py)

