M = float(input())
e = float(input())

print("total =", M + e)
