M = int(input())

if M == 1 or M == 3 or M == 5 or M == 7 or M == 9 or M == 10 or M == 12:
    print("31")
elif M == 2:
    print("28")
else :
    print("30")
