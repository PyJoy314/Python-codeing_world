entry, minecraft = input().split()

entry = int(entry)
minecraft = int(minecraft)

print(entry, "*", minecraft, "=", entry * minecraft)
