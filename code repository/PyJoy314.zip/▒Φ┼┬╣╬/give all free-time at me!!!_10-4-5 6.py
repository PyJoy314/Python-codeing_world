PI = 3.14
radius = int(input())
print(f"PI = PI{PI : .2f}")
print(f"Area = {radius} * {radius} * {PI} = {radius * radius * PI : .1f}")
