A, B = input().split()
if B in A * 3:
    print(A + B)
else :
    print(B * 2)
