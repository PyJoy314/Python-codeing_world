hap = 0
i = 1
while i <=10:
    hap += i
    i += 1
print(hap)
