tmp = input().strip()

print(tmp[::-1])
print(tmp)
