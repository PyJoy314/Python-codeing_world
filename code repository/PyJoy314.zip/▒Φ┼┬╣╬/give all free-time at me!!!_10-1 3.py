A = input().strip()
for i in range(len(A)):
    print(A[i], end=" [:[^].[-]:] ")
