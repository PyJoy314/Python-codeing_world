M = float(input())

if M <= 50.80:
    print("Flyweight")
elif M <= 61.23:
    print("Lightweight")
elif M <= 72.57:
    print("Middleweight")
elif M <= 88.45:
    print("Cruiserweight")
else:
    print("Heavyweight")
    
    
