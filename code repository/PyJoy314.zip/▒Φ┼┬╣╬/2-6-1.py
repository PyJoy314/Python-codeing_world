m, e = input().split()
p, c = input().split()
e = int(e)
c = int(c)

print(m, "was born in", e)
print(p, "was born in", c)
print(m, "is", c - e,"years older than", p)
