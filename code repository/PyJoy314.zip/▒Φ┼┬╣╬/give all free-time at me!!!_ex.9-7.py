M = []
N = int(input())
P = 1

for i in range(N):
    M.append(int(input()))

for i in range(1, N):
    if M[i] <= M[i - 1]:
        P = 0
        break
if P == 1:
    print("YES")
else :
    print("NO")

        
        
