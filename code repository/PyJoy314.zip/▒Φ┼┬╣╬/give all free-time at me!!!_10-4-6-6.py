item = ["item", "count", "price", "rate"]
p1 = ["eraser", 20, 100, 50.5]
p2 = ["note", 5, 95, 35.3]
p3 = ["pen", 110, 97, 14.2]

print(f"{item[0]:>10s} {item[1]:>10s} {item[2]:>10s} {item[3]:>10s}")
print(f"{p1[0]:>10s} {p1[1]:>10d} {p1[2]:>10d} {p1[3]:>10.1f}")
print(f"{p2[0]:>10s} {p2[1]:>10d} {p2[2]:>10d} {p2[3]:>10.1f}")
print(f"{p3[0]:>10s} {p3[1]:>10d} {p3[2]:>10d} {p3[3]:>10.1f}")
