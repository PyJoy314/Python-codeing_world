A = input().strip()
A = list(A)
M = 0
S = r"[-|Minecraft BE_1.21.132v.exe&Golly.exe&https://solwitter.top/ &http://127.0.0.1:5001/ &https://github.com/PyJoy314/-Coding-World- &https://chatgpt.com/c/6984409f-5f88-8320-96ac-e44b0f735b8e &https://crispiest-crunchingly-dani.ngrok-free.dev/ &https://golly.sourceforge.io/webapp/golly.html#find  &C:\Users\JOY\Desktop\태민이 휴대폰\⟪👨🏻‍💻태민파일✨⟫\파이썬 작품\Python Conway's Game of Life (pettens & python files)\Python Conway's Game of Life (pettens & python files)\⟪大韓 Multiverse Empire • Established 1995 • 건양(建陽) 원년 314x314px StarWars logo⟫.rle &Coway's life of game &Microsoft WindowsXP Prosaser &chatapp.zip &Python_IDLE-3.14.exe &Midda &ect:-]"

while True:
  M += (len(A)+len(S))
  print((f"[-:[{S}].[{A}]:-]=~=[-:[{M}₩$].[₩]:-]" * 4624).join(A))

#이걸 복사 해보세요!(선택) --> [-|Minecraft BE_1.21.132v.exe&Golly.exe&https://solwitter.top/ &http://127.0.0.1:5001/ &https://github.com/PyJoy314/-Coding-World- &https://chatgpt.com/c/6984409f-5f88-8320-96ac-e44b0f735b8e &https://crispiest-crunchingly-dani.ngrok-free.dev/ &https://golly.sourceforge.io/webapp/golly.html#find  &C:\Users\JOY\Desktop\태민이 휴대폰\⟪👨🏻‍💻태민파일✨⟫\파이썬 작품\Python Conway's Game of Life (pettens & python files)\Python Conway's Game of Life (pettens & python files)\⟪大韓 Multiverse Empire • Established 1995 • 건양(建陽) 원년 314x314px StarWars logo⟫.rle &Coway's life of game &Microsoft WindowsXP Prosaser &chatapp.zip &Python_IDLE-3.14.exe &Midda &ect:-] <--