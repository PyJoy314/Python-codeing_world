M = True
e = False
Py = False

print(not M)
print(M and e)
print(M or e)
print(M and (M or Py))
print(M or (M and Py))
print(not e or (M and not Py))
