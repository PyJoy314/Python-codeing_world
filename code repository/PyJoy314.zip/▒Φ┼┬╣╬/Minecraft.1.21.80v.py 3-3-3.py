M, e = input().split()
M = int(M)
e = int(e)

Minecraft1 = (M == e)
Minecraft2 = (M != e)

print(Minecraft1, Minecraft2)
