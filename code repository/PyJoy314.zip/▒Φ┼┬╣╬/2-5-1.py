entry, minecraft = input().split()
entry = int(entry)
minecraft = int(minecraft)

print(entry)
print(minecraft)
