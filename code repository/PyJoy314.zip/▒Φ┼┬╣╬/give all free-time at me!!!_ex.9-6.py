odd = []
even = []

while True:
    M = int(input())
    if M == 0:
        break
    if M % 2 == 0:
        even.append(M)
    if M % 2 == 1:
        odd.append(M)

print("odd = ",odd)
print("even = ",even)

        
    
