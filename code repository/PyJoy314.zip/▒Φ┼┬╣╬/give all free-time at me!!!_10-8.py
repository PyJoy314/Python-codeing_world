A = input().strip()
A = list(A)
print(','.join(A))
