py = int(input())
M, e = input().split()
M = int(M)
e = int(e)

result1 = (py == M)
result2 = (py == e)
result3 = (py != M)
result4 = (py != e)

print(result1, result2, result3, result4)
