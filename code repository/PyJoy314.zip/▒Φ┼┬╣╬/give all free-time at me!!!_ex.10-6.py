A, M = input().split()
A = list(A)
M = list(M)
print('.'.join(A)+".  ."+'.'.join(M))
