while True:
    M = int(input())
    if M >= 4:
        break
    if M == 1:
        print("one")
    if M == 3:
        print("three")
    if M == 7474747:
        print("Minecraft&entry")
    
