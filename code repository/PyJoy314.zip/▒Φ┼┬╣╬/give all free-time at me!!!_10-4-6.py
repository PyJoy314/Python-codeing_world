item = ["shoe", "bag"]
price = [75, 230]
print(" ITEM PRICE")
print(f"{item[0]:>5s} {price[0]:>5d}")
print(f"{item[1]:>5s} {price[1]:>5d}")
