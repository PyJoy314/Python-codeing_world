radius = float(input())
PI = radius / 3
print(f"{PI : .2f}")
