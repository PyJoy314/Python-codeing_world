cnt = [0]*11
while True:
    num = int(input())
    if num <1 or num > 10:
        break
    cnt[num]+=1

for  i in range(1, 11):
    if cnt[i]==0:
        continue
    print(f"{i}: {cnt[i]}")
